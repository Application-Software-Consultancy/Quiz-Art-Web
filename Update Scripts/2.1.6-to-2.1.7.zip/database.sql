UPDATE `tbl_settings` SET `message` = '2.1.7' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_web_settings`  ADD `language_id` INT NULL DEFAULT '14'  AFTER `id`;
ALTER TABLE `tbl_badges`  ADD `language_id` INT NOT NULL DEFAULT '14'  AFTER `id`;
DELETE FROM tbl_settings where type in ('notification_title', 'notification_body');
INSERT INTO `tbl_web_settings` (`id`, `language_id`, `type`, `message`) VALUES (NULL, '14', 'notification_title', 'Congratulations'), (NULL, '14', 'notification_body', 'You have unlocked new badge'),(NULL,'14','primary_color','#EF5388FF'),(NULL,'14','footer_color','#090029FF'),(NULL,'14','section_1_mode',1),(NULL,'14','section_2_mode',1),(NULL,'14','section_3_mode',1);
DELETE FROM tbl_web_settings where type in ('facebook_link_footer','instagram_link_footer','linkedin_link_footer','youtube_link_footer','toggle_web_home_settings');
INSERT INTO `tbl_settings` (`id`, `type`, `message`) VALUES (NULL, 'contest_mode_wrong_deduct_score', '4');
INSERT INTO `tbl_settings` (`id`, `type`, `message`) VALUES (NULL, 'contest_mode_correct_credit_score', '4');
