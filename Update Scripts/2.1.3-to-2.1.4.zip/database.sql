UPDATE `tbl_settings` SET `message` = '2.1.4' WHERE `tbl_settings`.`type` = 'system_version';
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'quiz_zone_mode', '1') AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_web_settings WHERE type  ='quiz_zone_mode') LIMIT 1;
